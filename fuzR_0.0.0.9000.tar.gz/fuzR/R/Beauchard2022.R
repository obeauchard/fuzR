#' Macrozoobenthic data set of the Dutch sector of the North Sea
#'
#' @format A list with the following components:
#' \describe{
#'   \item{\code{env}}{sampling stations x habitat descriptors data frame.}
#'   \item{\code{fau}}{sampling stations x taxa data frame.}
#'   \item{\code{geo}}{sampling stations x geographic coordinates data frame.}
#'   \item{\code{hab}}{factor identifying two habitats: "HD" for high hydrodynamics
#'   and "LD" for low hydrodynamics.}
#'   \item{\code{bat}}{Coarse bathymetric raster from the area.}
#' }
#'
#' @import raster
#'
#' @details
#' The four objects of the data set are matched to each other by sampling stations.
#'
#' @usage
#' data(Beauchard2022)
#'
#' @references
#' Beauchard O, Mestdagh S, Koop L, Ysebaert T, Herman PMJ (2022) Benthic synecology in a soft sediment shelf:
#' habitat contrasts and assembly rules of life strategies. Marine Ecology Progress Series 682:31–50
#' Beauchard O, Soetaert K (2026) MacroTraits: a global trait data and information system for marine benthic ecology.
"Beauchard2022"
